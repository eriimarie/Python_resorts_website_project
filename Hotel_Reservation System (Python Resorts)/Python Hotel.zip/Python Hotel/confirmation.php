<?php

require('database.php');

function generateRandomString($length = 10)
{
  $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
  $charactersLength = strlen($characters);
  $randomString = '';
  for ($i = 0; $i < $length; $i++) {
    $randomString .= $characters[rand(0, $charactersLength - 1)];
  }
  return $randomString;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $title = $_POST['title'] ?? '';
  $firstname = $_POST['firstname'] ?? '';
  $lastname = $_POST['lastname'] ?? '';
  $email = $_POST['email'] ?? '';
  $country = $_POST['country'] ?? '';
  $address = $_POST['address'] ?? '';
  $city = $_POST['city'] ?? '';
  $state = $_POST['state'] ?? '';
  $zipcode = $_POST['zipcode'] ?? '';
  $checkin = $_POST['checkin'] ?? '';
  $checkout = $_POST['checkout'] ?? '';
  $rooms = $_POST['rooms'] ?? '';
  $adults = $_POST['adults'] ?? '';
  $children = $_POST['children'] ?? '';
  $type = $_POST['type'] ?? '';
  $total = 0;
  if ($type == 'Standard') {
    $price = 150;
  } else if ($type == 'Queen') {
    $price = 180;
  } else if ($type == 'King') {
    $price = 210;
  } else if ($type == 'double') {
    $price = 230;
    $type = 'Double Queen';
  } else if ($type == 'Penthouse') {
    $price = 350;
  }

  $stmt = $db->prepare('SELECT * FROM rooms WHERE type = ? LIMIT 1');
  $stmt->bind_param('s', $type);

  $stmt->execute();
  $result = $stmt->get_result();
  
  $room = $result->fetch_assoc();
  $roomsId = $room['roomsId'];
 

  $rooms = $_POST['rooms'] ?? '';

  $address2 = null;
  $status = 'Confirmed';
  $reservationId = generateRandomString(10);
  $total = $price * $rooms;

  $stmt = $db->prepare('INSERT INTO 
  `reservations` 
  (`reservationId`, 
  `roomsId`, 
  `first_name`, 
  `last_name`, 
  `email`, 
  `total`,
  `number_of_rooms`,
  `number_of_adults`, 
  `number_of_children`, 
  `country`, 
  `addressLOne`, 
  `addressLTwo`, 
  `city`, 
  `state`, 
  `zipCode`, 
  `checkIn`, 
  `checkOut`, 
  `status`) 
  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
  $stmt->bind_param(
    'sisssiiiisssssisss',
    $reservationId,
    $roomsId,
    $firstname,
    $lastname,
    $email,
    $total,
    $rooms,
    $adults,
    $children,
    $country,
    $address,
    $address2,
    $city,
    $state,
    $zipcode,
    $checkin,
    $checkout,
    $status
  );
  $stmt->execute();
  $x = mysqli_error($db
  );
  print_r($x);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="./customerInfoStyle.css" rel="stylesheet" type="text/css">
  <link href="./confirmation.css" rel="stylesheet" type="text/css">
  <title>Confirmation</title>
</head>

<body>

  <header>
    <div>
      <div class="left-row">
        <ul>
          <li><img src="pythonLogo1.png" width="50" height="50" alt="PYTHON"></li>
          <li>
            <p style="color:white;"><b>PYTHON RESORTS&trade;</b></p>
          </li>
        </ul>
      </div>
    </div>
    <div class="centered-row">
      <ul>
        <li><a href="index.html"> HOME </a></li>
        <li><a href="aboutUs.html"> ABOUT US </a></li>
        <li class="active"><a href=""> BOOKING </a></li>
      </ul>
    </div>
  </header>

  <div class="title">
    <h1>THANK YOU FOR BOOKING WITH US!</h1>
  </div>
  <br>
  <hr>
  <br>
  <div class="main">
    <img src="./pythonLogo1.png" alt="Python logo" class="logo">
  <div class="booking-information">
    <div class="input">
      <p class="label">CHECK-IN: </p>
      <p class="value"><?php echo date('Y/m/d', strtotime($checkin)); ?></p>
    </div>
    <div class="input">
      <p class="label">CHECK-OUT: </p>
      <p class="value"><?php echo date('Y/m/d', strtotime($checkout)); ?></p>
    </div>
    <div class="input">
      <p class="label">ROOM TYPE: </p>
      <p class="value"><?php echo $type; ?></p>
    </div>
    <div class="input">
      <p class="label"># OF ROOMS: </p>
      <p class="value"><?php echo $rooms; ?></p>
    </div>
    <div class="input">
      <p class="label">NUMBER OF ADULTS: </p>
      <p class="value"><?php echo $adults; ?></p>
    </div>
    <div class="input">
      <p class="label">NUMBER OF CHILDREN: </p>
      <p class="value"><?php echo $children; ?></p>
    </div>
  </div>

  <div class="more-booking-information">
  <div class="more-input">
      <p class="more-label">CONFIRMATION NUMBER: </p>
      <p class="more-value"><?php echo $reservationId; ?></p>
    </div>
    <div class="more-input">
      <p class="more-label">FIRST NAME: </p>
      <p class="more-value"><?php echo $firstname; ?></p>
    </div>
    <div class="more-input">
      <p class="more-label">LAST NAME: </p>
      <p class="more-value"><?php echo $lastname; ?></p>
    </div>
    <div class="more-input">
      <p class="more-label">EMAIL ADDRESS: </p>
      <p class="more-value"><?php echo $email; ?></p>
    </div>
    <div class="more-input">
      <p class="more-label">ADDRESS: </p>
      <p class="more-value"><?php echo $address; ?></p>
    </div>
    <div class="more-input">
      <p class="more-label">STATE: </p>
      <p class="more-value"><?php echo $state; ?></p>
    </div>
    <div class="more-input">
      <p class="more-label">CITY: </p>
      <p class="more-value"><?php echo $city; ?></p>
    </div>
    <div class="more-input">
      <p class="more-label">ZIP CODE: </p>
      <p class="more-value"><?php echo $zipcode; ?></p>
    </div>
   
    <div class="more-input" style="margin-top: 4em;">
      <h1 class="more-label" style="width: 200px;">TOTAL COST: </h1>
      <h2 class="more-value">$<?php echo $total; ?>.00</h2>
    </div>


  </div>
  </div>

  <br>
  <footer>
    <div class="footer">
      <p class="address-contact">Address:<span style="margin-left: 25px;"></span>
      <a href="https://www.google.com/maps/place/1+Normal+Ave,+Montclair,+NJ+07043/@40.8622763,-74.2001893,17z/data=!3m1!4b1!4m5!3m4!1s0x89c2ffc95861e30f:0xcb7e0e8383cbf5bf!8m2!3d40.8622763!4d-74.1980006?hl=en%22%3E">
                1 Normal Ave<br><span style="margin-left: 95px;"></span>Montclair, NJ 07043</a><br>
        Contact:<span style="margin-left: 27px;"></span> 973-973-4000 <br>
        <img src="fbIcon.png" width="20" height="20" alt="FaceBook"> <span style="margin-left: 5px;"></span>
        <img src="igIcon.png" width="20" height="20" alt="Instagram"><span style="margin-left: 5px;"></span>
        <img src="twitterIcon.png" width="20" height="20" alt="Twitter">
      </p>
      <p class="copy-right">Copyright&#169 Python Resorts. All rights reserved.</p>
    </div>
  </footer>

</body>

</html>
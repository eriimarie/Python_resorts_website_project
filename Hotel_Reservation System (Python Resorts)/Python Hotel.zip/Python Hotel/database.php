<?php
$host = "localhost";
$username = "pythonresorts";
$password = "pythonresortspass";
$db_name = "pythonresortsdb";

$db = mysqli_connect("$host", "$username", "$password", "$db_name") or die("cannot connect");
if (mysqli_connect_errno()) {
    echo "Failed to Connect Database: " . mysqli_connect_error();
    exit();
}

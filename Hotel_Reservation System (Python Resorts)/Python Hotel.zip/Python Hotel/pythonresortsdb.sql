-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 03, 2021 at 08:44 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pythonresortsdb`
--

-- --------------------------------------------------------

GRANT SELECT, INSERT, DELETE, UPDATE
ON pythonresortsdb.*
TO pythonresorts@localhost
IDENTIFIED BY 'pythonresortspass';

--
-- Table structure for table `reservations`
--

CREATE TABLE `reservations` (
  `reservationId` varchar(200) NOT NULL,
  `roomsId` int(11) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `total` int(11) NOT NULL,
  `number_of_rooms` int(11) NOT NULL,
  `number_of_adults` int(11) NOT NULL,
  `number_of_children` int(11) DEFAULT NULL,
  `country` varchar(200) NOT NULL,
  `addressLOne` varchar(200) NOT NULL,
  `addressLTwo` varchar(200) DEFAULT NULL,
  `city` varchar(200) NOT NULL,
  `state` varchar(200) NOT NULL,
  `zipCode` int(11) NOT NULL,
  `checkIn` date NOT NULL,
  `checkOut` date NOT NULL,
  `status` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reservations`
--

INSERT INTO `reservations` (`reservationId`, `roomsId`, `first_name`, `last_name`, `email`, `total`, `number_of_rooms`, `number_of_adults`, `number_of_children`, `country`, `addressLOne`, `addressLTwo`, `city`, `state`, `zipCode`, `checkIn`, `checkOut`, `status`) VALUES
('5TRu7bx6eU', 101, 'Phil', 'Murphy', 'murphyP@nj.gov', 150, 1, 1, 1, 'United States of America', '1 Trenton Ave', NULL, 'Trenton', 'New Jersey', 7777, '2021-04-03', '2021-04-13', 'Confirmed'),
('abcdefgh', 101, 'joe', 'z', 'x@x.com', 150, 1, 2, 2, 'country', 'a1', 'a2', 'city', 'state', 11366, '2021-04-01', '2021-04-09', 'pending'),
('fyts3pFFjn', 101, 'Joe', 'Smith', 'joesmith@gmail.com', 150, 1, 1, 1, 'United States of America', '123 Main Street', NULL, 'Somewhere', 'Kansas', 12345, '2021-04-12', '2021-04-15', 'Confirmed'),
('XXzOhXtfaz', 104, 'Joseph', 'Biden', 'bidenJ@whitehouse.gov', 350, 1, 1, 0, 'United States of America', '1600 Pennsylvania Avenue NW', NULL, 'Washington', 'DC', 20500, '2021-04-19', '2021-04-21', 'Confirmed');

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `roomsId` int(11) NOT NULL,
  `type` enum('Standard','Queen','Double Queen','King','Penthouse') DEFAULT NULL,
  `price` decimal(5,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`roomsId`, `type`, `price`) VALUES
(101, 'Standard', '150.00'),
(102, 'King', '210.00'),
(103, 'Standard', '150.00'),
(104, 'Penthouse', '350.00'),
(105, 'Queen', '180.00'),
(107, 'Standard', '150.00'),
(108, 'Penthouse', '350.00'),
(109, 'Double Queen', '230.00'),
(111, 'King', '210.00'),
(112, 'King', '210.00'),
(113, 'Queen', '180.00'),
(114, 'King', '210.00'),
(115, 'Standard', '150.00'),
(116, 'Penthouse', '350.00'),
(117, 'Double Queen', '230.00'),
(118, 'Queen', '180.00'),
(201, 'Queen', '180.00'),
(202, 'Double Queen', '230.00'),
(203, 'Penthouse', '350.00'),
(204, 'Double Queen', '230.00'),
(206, 'Standard', '150.00'),
(207, 'Penthouse', '350.00'),
(208, 'King', '210.00'),
(209, 'Standard', '150.00'),
(301, 'King', '210.00'),
(302, 'Queen', '180.00'),
(303, 'Double Queen', '230.00'),
(304, 'Standard', '150.00'),
(306, 'Penthouse', '350.00'),
(307, 'Double Queen', '230.00'),
(308, 'Penthouse', '350.00'),
(309, 'Standard', '150.00'),
(401, 'Double Queen', '230.00'),
(402, 'King', '210.00'),
(403, 'Standard', '150.00'),
(404, 'King', '210.00'),
(406, 'King', '210.00'),
(407, 'Standard', '150.00'),
(408, 'Standard', '150.00'),
(409, 'King', '210.00'),
(501, 'Penthouse', '350.00'),
(502, 'King', '210.00'),
(503, 'Double Queen', '230.00'),
(504, 'Standard', '150.00'),
(506, 'Queen', '180.00'),
(507, 'Double Queen', '230.00'),
(508, 'Standard', '150.00'),
(509, 'Penthouse', '350.00'),
(601, 'Standard', '150.00'),
(602, 'Standard', '150.00'),
(603, 'Double Queen', '230.00'),
(604, 'Queen', '180.00'),
(606, 'Queen', '180.00'),
(607, 'Queen', '180.00'),
(608, 'Double Queen', '230.00'),
(609, 'King', '210.00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`reservationId`),
  ADD KEY `roomsId` (`roomsId`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`roomsId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `roomsId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=610;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `reservations`
--
ALTER TABLE `reservations`
  ADD CONSTRAINT `reservations_ibfk_1` FOREIGN KEY (`roomsId`) REFERENCES `rooms` (`roomsId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
